Hospital = function(context) {
    this.background = context.add.image(-8, -10, 'hospital');

    this.background.setOrigin(0,0);
    // this.background.setDepth(999);


    // this.background.setPosition(0, 0);
    // this.background.setScale(0.87,0.87);
}